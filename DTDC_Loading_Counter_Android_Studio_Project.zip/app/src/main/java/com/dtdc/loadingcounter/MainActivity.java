package com.dtdc.loadingcounter;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, entriesBox, historyBox, loaderBox;
    Spinner loaderSpinner, countSpinner;
    TextView totalText, tripText;
    EditText vehicleInput;
    ArrayList<String> loaders = new ArrayList<>(Arrays.asList("Loader 1","Loader 2","Loader 3"));
    JSONArray entries = new JSONArray(), history = new JSONArray();
    int selectedCount = 1;
    String pendingCsv = "";
    android.content.SharedPreferences prefs;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("dtdc_counter",MODE_PRIVATE);
        try { history=new JSONArray(prefs.getString("history","[]")); } catch(Exception e){}
        for(int i=0;i<3;i++) loaders.set(i,prefs.getString("loader"+i, "Loader "+(i+1)));
        buildUI(); loadCurrent();
    }
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(4),dp(6),dp(4),dp(6)); return t; }
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(16),dp(8),dp(16),dp(12)); return l; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    void buildUI(){
        ScrollView scroll=new ScrollView(this); root=vertical(); root.setBackgroundColor(Color.rgb(246,247,249)); scroll.addView(root); setContentView(scroll);
        TextView title=text("DTDC LOADING COUNTER",23,Color.WHITE); title.setGravity(Gravity.CENTER);
        LinearLayout header=vertical(); header.setBackgroundColor(Color.rgb(183,18,28)); header.addView(title); root.addView(header);
        tripText=text("CURRENT LOADING",17,Color.rgb(160,15,25)); root.addView(tripText);
        vehicleInput=new EditText(this); vehicleInput.setSingleLine(true); vehicleInput.setHint("Vehicle / Guide number (optional)"); root.addView(vehicleInput);
        loaderSpinner=new Spinner(this); loaderSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,loaders)); root.addView(text("Select loader",14,Color.DKGRAY)); root.addView(loaderSpinner);
        countSpinner=new Spinner(this); countSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"1 Parcel","2 Parcels","3 Parcels","4 Parcels"})); root.addView(text("Parcels carried in this trip",14,Color.DKGRAY)); root.addView(countSpinner);
        Button add=btn("+ ADD LOADING ENTRY"); root.addView(add); add.setOnClickListener(v->addEntry());
        totalText=text("TOTAL PARCELS: 0",24,Color.rgb(183,18,28)); totalText.setGravity(Gravity.CENTER); root.addView(totalText);
        loaderBox=vertical(); root.addView(loaderBox);
        Button editLoaders=btn("EDIT LOADER NAMES"); root.addView(editLoaders); editLoaders.setOnClickListener(v->editLoaderNames());
        Button export=btn("EXPORT REPORT TO EXCEL (CSV)"); root.addView(export); export.setOnClickListener(v->exportCsv());
        Button undo=btn("UNDO LAST ENTRY"); root.addView(undo); undo.setOnClickListener(v->undo());
        Button complete=btn("COMPLETE & SAVE THIS VEHICLE"); root.addView(complete); complete.setOnClickListener(v->completeTrip());
        TextView eh=text("CURRENT ENTRIES",17,Color.rgb(40,40,40)); root.addView(eh);
        entriesBox=vertical(); root.addView(entriesBox);
        TextView hh=text("SAVED LOADING HISTORY",19,Color.rgb(183,18,28)); root.addView(hh);
        historyBox=vertical(); root.addView(historyBox);
        Button clear=btn("CLEAR ALL SAVED HISTORY"); root.addView(clear); clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete all history?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{history=new JSONArray();save();render();}).show());
    }
    void editLoaderNames(){
        LinearLayout form=vertical();
        EditText[] fields=new EditText[3];
        for(int i=0;i<3;i++){
            fields[i]=new EditText(this); fields[i].setSingleLine(true); fields[i].setHint("Loader "+(i+1)+" name"); fields[i].setText(loaders.get(i)); form.addView(fields[i]);
        }
        new AlertDialog.Builder(this).setTitle("Edit loader names").setView(form)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                for(int i=0;i<3;i++){String value=fields[i].getText().toString().trim(); if(!value.isEmpty()) loaders.set(i,value); prefs.edit().putString("loader"+i,loaders.get(i)).apply();}
                loaderSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,loaders));
                render();
            }).show();
    }
    String csv(String value){
        if(value==null)value="";
        return "\""+value.replace("\"","\"\"")+"\"";
    }
    void exportCsv(){
        if(history.length()==0){Toast.makeText(this,"No saved reports to export",Toast.LENGTH_SHORT).show();return;}
        StringBuilder out=new StringBuilder();
        out.append("Vehicle,Date,Loader,Parcels,Entry Time,Trip Total\\n");
        for(int i=history.length()-1;i>=0;i--){
            JSONObject trip=history.optJSONObject(i); JSONArray es=trip.optJSONArray("entries");
            if(es==null || es.length()==0){
                out.append(csv(trip.optString("vehicle"))).append(",").append(csv(trip.optString("date"))).append(",,,").append(",").append(trip.optInt("total")).append("\\n");
            } else {
                for(int j=0;j<es.length();j++){
                    JSONObject e=es.optJSONObject(j);
                    out.append(csv(trip.optString("vehicle"))).append(",")
                       .append(csv(trip.optString("date"))).append(",")
                       .append(csv(e.optString("loader"))).append(",")
                       .append(e.optInt("count")).append(",")
                       .append(csv(e.optString("time"))).append(",")
                       .append(trip.optInt("total")).append("\\n");
                }
            }
        }
        pendingCsv="\\uFEFF"+out.toString();
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE,"DTDC_Loading_Report.csv");
        startActivityForResult(intent, 741);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==741 && resultCode==RESULT_OK && data!=null){
            try{
                Uri uri=data.getData();
                OutputStream stream=getContentResolver().openOutputStream(uri);
                BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(stream,"UTF-8"));
                writer.write(pendingCsv); writer.flush(); writer.close();
                Toast.makeText(this,"Excel-compatible report exported",Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }
    void addEntry(){
        try{
            JSONObject o=new JSONObject(); o.put("loader",loaderSpinner.getSelectedItem().toString());
            o.put("count",countSpinner.getSelectedItemPosition()+1);
            o.put("time",new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date()));
            entries.put(o); saveCurrent(); render();
        }catch(Exception e){}
    }
    void undo(){ if(entries.length()>0){entries=removeLast(entries); saveCurrent(); render();} }
    JSONArray removeLast(JSONArray a){ JSONArray n=new JSONArray(); for(int i=0;i<a.length()-1;i++) n.put(a.opt(i)); return n; }
    int total(JSONArray a){int n=0; for(int i=0;i<a.length();i++) n+=a.optJSONObject(i).optInt("count"); return n;}
    void completeTrip(){
        if(entries.length()==0){Toast.makeText(this,"No loading entries yet",Toast.LENGTH_SHORT).show();return;}
        try{
            JSONObject trip=new JSONObject(); trip.put("vehicle",vehicleInput.getText().toString().trim().isEmpty()?"Vehicle not named":vehicleInput.getText().toString().trim());
            trip.put("date",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));
            trip.put("total",total(entries)); trip.put("entries",new JSONArray(entries.toString()));
            history.put(0,trip); entries=new JSONArray(); vehicleInput.setText(""); save(); saveCurrent(); render();
            Toast.makeText(this,"Loading report saved",Toast.LENGTH_LONG).show();
        }catch(Exception e){}
    }
    void loadCurrent(){try{entries=new JSONArray(prefs.getString("current","[]")); vehicleInput.setText(prefs.getString("vehicle",""));}catch(Exception e){} render();}
    void saveCurrent(){prefs.edit().putString("current",entries.toString()).putString("vehicle",vehicleInput.getText().toString()).apply();}
    void save(){prefs.edit().putString("history",history.toString()).apply();}
    void render(){
        totalText.setText("TOTAL PARCELS: "+total(entries));
        loaderBox.removeAllViews();
        for(String name:loaders){int n=0; for(int i=0;i<entries.length();i++){JSONObject o=entries.optJSONObject(i);if(name.equals(o.optString("loader")))n+=o.optInt("count");}
            loaderBox.addView(text(name+"  •  "+n+" parcels",16,Color.DKGRAY));
        }
        entriesBox.removeAllViews();
        for(int i=entries.length()-1;i>=0;i--){JSONObject o=entries.optJSONObject(i); entriesBox.addView(text((entries.length()-i)+". "+o.optString("loader")+"  •  "+o.optInt("count")+" parcel(s)  •  "+o.optString("time"),14,Color.DKGRAY));}
        historyBox.removeAllViews();
        if(history.length()==0) historyBox.addView(text("No saved reports yet.",14,Color.GRAY));
        for(int i=0;i<history.length();i++){JSONObject h=history.optJSONObject(i); LinearLayout card=vertical(); card.setBackgroundColor(Color.WHITE);
            card.addView(text(h.optString("vehicle")+"  |  "+h.optInt("total")+" parcels",17,Color.BLACK));
            card.addView(text(h.optString("date"),13,Color.GRAY));
            JSONArray es=h.optJSONArray("entries"); if(es!=null) for(int j=0;j<es.length();j++){JSONObject e=es.optJSONObject(j); card.addView(text(e.optString("loader")+" : "+e.optInt("count")+" parcel(s)",13,Color.DKGRAY));}
            historyBox.addView(card);
        }
        saveCurrent();
    }
    @Override protected void onPause(){super.onPause();saveCurrent();}
}